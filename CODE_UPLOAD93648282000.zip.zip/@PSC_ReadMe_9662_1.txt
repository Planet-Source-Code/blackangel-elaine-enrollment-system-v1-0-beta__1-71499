Title: Setup program III
Description: UPDATED (ver 1.3)! If you have done a program you maybe want to make your own Installer program for it. Here it is. Your own Installer program with compression. You can make the Installer just like you want. Or if you want to make a Setup program like Wise Install or Install-us. Make one yourself.
New in this version (1.3) is a working Install directory. It will add shortcuts to your program. And a much better interface.
Please VOTE if you like the program.
Do you want to make more money while you programming? Goto: http://www.paidforsurf.com/index.asp?refid=rompa
 and get paid.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=9662&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
