********************************************
*         Created by Ronnie Staxborn       *
*      					   *
*    More information in the projects      *
********************************************

Version 1.3

I have now added the making of shortcuts in the Installer.
But if you know a better way of making it witout the 
"vb6stkit.dll" file, please drop me a note.
The shortcuts will be stored to the start menu.
In the Make Installer, note that the exename is correct.
If not the shortcut will not work properly.

I want to change this option. That you can "check" for witch 
program that it will create a shortcut for.

Version 1.2

Now you can add your dependencies for your programs.
for E.g your ocx, dll etc.
New "style" on the Installer.
Added a "preinstall" so now you can add more
info to the program if you like in a setupinfo.ini
file. The install directory in the program is now fully working.
No more [] signs at the end of the installdirectory.

Version 1.1

Added the function to add the file Unzip32.dll automatically 
to the windows\system directory. It's for the end user who might
not have the unzip32.dll file in there computer. This way they 
will not get any error and the setup will go on.

Version 1.0

First release of the Installer.

NOTE:
The 'Installer template' is "Installer.exe" in this folder.

PLANNING:
Planning to make shortcuts to the installed programs. 
Anyone with an idea? For e.g. if you want a shortcut
to the users desktop it will be created there without
any promt for the enduser. 

Any questions or ideas? Please let me know.

Ronnie Staxborn
rompa@hem.passagen.se

